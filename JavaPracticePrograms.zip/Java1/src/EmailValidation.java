
public class EmailValidation {

}
