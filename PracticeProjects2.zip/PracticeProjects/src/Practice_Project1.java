
public class Practice_Project1 {
	public static void main(String[] args) {
			
			//implicit conversion
			System.out.println("Implicit Type Casting");
			int a=10;
			System.out.println("Value of a: "+a);
			
			float b=a;
			System.out.println("Value of b: "+b);
			
			long c=a;
			System.out.println("Value of c: "+c);
			
			double d=a;
			System.out.println("Value of d: "+d);
			System.out.println("\n");
			System.out.println("Implicity converting char datatype to other datatypes");
			char e='B';
			System.out.println("Value of e: "+e);
			int f=e;
			System.out.println("Value of f: "+f);
			
			float g=e;
			System.out.println("Value of g: "+g);
			
			long h=e;
			System.out.println("Value of h: "+h);
			
			double i=e;
			System.out.println("Value of i: "+i);
			
					
			System.out.println("\n");
			
			System.out.println("Explicit Type Casting");
			//explicit conversion
			
			double x=45.5;
			int y=(int)x;
			System.out.println("Value of x: "+x);
			System.out.println("Value of y: "+y);
			float z=100.11f;
			char w =(char)z;
			System.out.println("Value of z: "+z);
			System.out.println("Value of w: "+w);
			
		}
	}


