package accessmodifiers;
//import Modifiers.*;
public class Modifiers1 {
	public static void main(String args[])
	{
		Modifiers m=new Modifiers();
		//System.out.println(m.a);//private cant be access
		System.out.println(m.c);
		System.out.println(m.d);
		System.out.println(m.b);
	}

}
