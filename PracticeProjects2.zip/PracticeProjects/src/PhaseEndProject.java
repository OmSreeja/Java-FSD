import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class PhaseEndProject {

	public static void main(String[] args) {
		

	}

}
