package com.example.springbootwithdocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
